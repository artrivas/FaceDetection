import React, { useRef, useState, useEffect } from "react";
import axios from "axios";

function App() {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  // Cambia por tu URL de Ngrok
  const [url] = useState("https://b205-38-253-159-7.ngrok-free.app/detectar");

  useEffect(() => {
    // Iniciar la cámara
    navigator.mediaDevices.getUserMedia({ video: true }).then((stream) => {
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    });
  }, []);

  useEffect(() => {
    const intervalo = setInterval(() => {
      detectar();
    }, 400);
    return () => clearInterval(intervalo);
  }, []);

  const detectar = async () => {
    if (!videoRef.current) return;

    const canvas = document.createElement("canvas");
    canvas.width = 640;
    canvas.height = 480;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(videoRef.current, 0, 0, 640, 480);

    canvas.toBlob(async (blob) => {
      const formData = new FormData();
      formData.append("file", blob, "frame.jpg");

      try {
        const response = await axios.post(url, formData);
        const resultados = response.data.resultados;
        dibujarResultados(resultados);
      } catch (error) {
        console.error("Error en la detección:", error);
      }
    }, "image/jpeg");
  };

  const dibujarResultados = (resultados) => {
    const ctx = canvasRef.current.getContext("2d");
    ctx.clearRect(0, 0, 640, 480);
    ctx.lineWidth = 2;
    ctx.font = "18px Arial";

    resultados.forEach((r) => {
      const [x1, y1, x2, y2] = r.box;

      ctx.strokeStyle = r.color || "lime";
      ctx.fillStyle = r.color || "lime";

      // Dibuja el rectángulo
      ctx.strokeRect(x1, y1, x2 - x1, y2 - y1);

      // Texto con emoji + emoción + confianza
      const texto = `${r.emoji} ${r.emocion} (${(r.confianza * 100).toFixed(1)}%)`;

      // Fondo del texto para visibilidad
      const textWidth = ctx.measureText(texto).width;
      ctx.fillRect(x1 - 2, y1 - 22, textWidth + 8, 20);

      // Texto encima del fondo
      ctx.fillStyle = "#ffffff";
      ctx.fillText(texto, x1 + 2, y1 - 7);
    });
  };

  return (
    <div style={{ textAlign: "center", paddingTop: "20px" }}>
      <h1 style={{ fontSize: "24px", fontWeight: "bold", marginBottom: "20px" }}>
        Detector de emociones en tiempo real
      </h1>

      <div
        style={{
          position: "relative",
          width: "640px",
          height: "480px",
          margin: "0 auto",
          boxShadow: "0px 0px 15px rgba(0,0,0,0.3)",
          borderRadius: "10px",
          overflow: "hidden",
        }}
      >
        <video
          ref={videoRef}
          width="640"
          height="480"
          autoPlay
          playsInline
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            zIndex: 1,
            objectFit: "cover",
          }}
        />
        <canvas
          ref={canvasRef}
          width="640"
          height="480"
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            zIndex: 2,
            pointerEvents: "none",
          }}
        />
      </div>
    </div>
  );
}

export default App;
